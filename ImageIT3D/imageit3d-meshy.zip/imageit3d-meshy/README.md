# ImageIT3D + LaunchIT3D

Idea-to-listing pipeline for non-technical 3D print sellers (SEMO capstone).

## Run it locally

1. Install Node.js 18 or newer.
2. `npm install`
3. Copy `.env.example` to `.env` and paste your Meshy API key (meshy.ai/settings/api).
   Creating Meshy tasks needs a paid Meshy plan with credits.
4. `npm start`, then open http://localhost:3000

The "Generate with Meshy" box appears under Design once the server has a key.

## How the Meshy connection works

Browser -> this server -> Meshy. The API key lives only in `.env` on the server.

| Route | What it does |
| --- | --- |
| `GET /api/meshy/health` | Tells the page whether Meshy is set up |
| `POST /api/meshy/preview` | Starts a Text to 3D preview task (geometry only) |
| `GET /api/meshy/tasks/:id` | Status and progress |
| `GET /api/meshy/tasks/:id/model?format=glb` | Downloads the finished model through the server |

The page polls every 4 seconds, downloads the GLB, and runs it through the same
import path as a manual upload: printability checks, pricing, listing, export.

## Never commit `.env`

It's in `.gitignore`. Each teammate uses their own copy. If a key is ever pushed
to GitHub, revoke it in Meshy right away and make a new one.
